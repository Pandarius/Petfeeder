import ConfigParser
from pymongo import MongoClient

class SettingMongo(object):
    """Setting MongoDB provider"""
    def __init__(self):
        config = ConfigParser.RawConfigParser()
        config.read('pilocal.cfg')
        self._settings = MongoClient(config.get('mongo', 'connection'))[config.get('mongo', 'db')]['settings']

    def get(self, key):
        setting = self._settings.find_one({ 'key': key })
        if setting:
            return setting['value']
        return None

    def update(self, key, value):
        result = self._settings.update_one({'key': key}, { '$set' : { 'value': value }})
        return result.modified_count == 1

    def add(self, key, value):
        self._settings.insert_one({'key': key, 'value': value})