class Gate(object):
    def open(self):
        # Gate open logic here
        return None

    def close(self, key, value):
        # Gate close logic here
        return None