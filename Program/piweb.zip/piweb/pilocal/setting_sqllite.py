import ConfigParser, sqlite3

class SettingSqlLite(object):
    """Report SqlLite provider"""
    def __init__(self):
        config = ConfigParser.RawConfigParser()
        config.read('pilocal.cfg')

        self._connection = config.get('sqllite', 'connection')
        self._settings = 'settings'
        
        self._conn = sqlite3.connect(self._connection)
        self._cursor = self._conn.cursor()
        self._cursor.execute("CREATE TABLE IF NOT EXISTS {0} (key text, value text)".format(self._settings))
        self._conn.commit()
        self._conn.close()

    def get(self, key):
        self._conn = sqlite3.connect(self._connection)
        self._cursor = self._conn.cursor()
        self._cursor.execute("SELECT * FROM {0} WHERE key = '{1}';".format(self._settings, key))
        setting = self._cursor.fetchone()
        self._conn.close()
        if setting:
            return setting[1]
        return None

    def add(self, key, value):
        self._conn = sqlite3.connect(self._connection)
        self._cursor = self._conn.cursor()
        self._cursor.execute("INSERT INTO {0} (key, value) VALUES ('{1}', '{2}')".format(self._settings, key, value))
        self._conn.commit()
        self._conn.close()

    def update(self, key, value):
        self._conn = sqlite3.connect(self._connection)
        self._cursor = self._conn.cursor()
        self._cursor.execute("UPDATE {0} SET value = '{1}' WHERE key = '{2}'".format(self._settings, value, key))
        self._conn.commit()
        self._conn.close()

    def set_defaults(self):
        if self.get('job_diff') == None:
            self.add('job_diff', 60)