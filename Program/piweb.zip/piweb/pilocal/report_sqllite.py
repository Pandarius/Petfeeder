import ConfigParser, sqlite3

class ReportSqlLite(object):
    """Report SqlLite provider"""
    def __init__(self):
        config = ConfigParser.RawConfigParser()
        config.read('pilocal.cfg')

        self._connection = config.get('sqllite', 'connection')
        self._reports = 'reports'
        
        self._conn = sqlite3.connect(self._connection)
        self._cursor = self._conn.cursor()
        self._cursor.execute("CREATE TABLE IF NOT EXISTS {0} (id INTEGER PRIMARY KEY AUTOINCREMENT, date text, success text, report text)".format(self._reports))
        self._conn.commit()
        self._conn.close()

    def get_by_id(self, id):
        self._conn = sqlite3.connect(self._connection)
        self._cursor = self._conn.cursor()
        self._cursor.execute("SELECT * FROM {0} WHERE id = {1};".format(self._reports, id))
        one = self._cursor.fetchone()
        self._conn.close()
        return one

    def all(self):
        self._conn = sqlite3.connect(self._connection)
        self._cursor = self._conn.cursor()
        self._cursor.execute("SELECT * FROM {0} ORDER BY id DESC LIMIT 500;".format(self._reports))
        all = self._cursor.fetchall()
        self._conn.close()
        return all

    def last(self):
        self._conn = sqlite3.connect(self._connection)
        self._cursor = self._conn.cursor()
        self._cursor.execute("SELECT * FROM {0} ORDER BY id DESC LIMIT 1;".format(self._reports))
        last = self._cursor.fetchone()
        self._conn.close()
        return last
    

    def add(self, doc):
        self._conn = sqlite3.connect(self._connection)
        # reports, strftime("%a, %d %b %Y %H:%M:%S +0000", gmtime()), True, 'Text 123'
        self._cursor = self._conn.cursor()
        self._cursor.execute("INSERT INTO {0} (date,success,report) VALUES ('{1}','{2}','{3}')".format(self._reports, doc['date'], doc['success'], doc['report']))
        self._conn.commit()
        self._conn.close()
