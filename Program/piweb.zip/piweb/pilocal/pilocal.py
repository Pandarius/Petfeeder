import requests, json, sched, time, logging, six, sqlite3, ConfigParser
from time import strftime, gmtime
from datetime import datetime, timedelta
from random import randint
from report_sqllite import ReportSqlLite
from report_mongo import ReportMongo
from setting_sqllite import SettingSqlLite
from setting_mongo import SettingMongo

report_sqllite = ReportSqlLite()
report_mongo = ReportMongo()
settings_sqllite = SettingSqlLite()
settings_mongo = SettingMongo()

# Configuration variables.
config = ConfigParser.RawConfigParser()
config.read('piweb.cfg')

settings_sqllite.set_defaults()

# JOB_DIFF is how often update will occur in seconds. JOB_DIFF = 30 seconds.
JOB_DIFF = int(settings_sqllite.get('job_diff'))
job = sched.scheduler(time.time, time.sleep)

# Basic logging added to track the actions.
logging.basicConfig(filename='log.txt',level=logging.INFO, format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')

# The actual code goes here.
def execute(job): 
    now = datetime.utcnow()
    report_message = ""

    # If logging level is set to INFO log then log event.
    logging.info('Job started')
    print("Job started at {0}".format(strftime("%a, %d %b %Y %H:%M:%S +0000", gmtime())))

    try:
        # Your execution logic here:


        # End the task
        report_message = "Job finished at {0}".format(strftime("%a, %d %b %Y %H:%M:%S +0000", gmtime()))
        print(report_message)
        logging.info(report_message)

    except Exception as ex:
        report_message = 'Job error: {0}'.format(ex)
        print(report_message)
        logging.error(report_message)

    try:
        send_report(report_message)
    except Exception as ex:
        logging.error('send_report error: {0}'.format(ex)) 

    job.enter(JOB_DIFF, 1, execute, (job,))

def main():
    now = datetime.utcnow()
    # get from mongo , sync the settings
    # if cant proceed without
    # check if it is time
    # open -> picture -> wait -> close -> picture
    # report
    # report to mongo if possible
    # check the level, if to low email

def send_report(): 
    print 'report'

def tests():
    #report_sqllite.add({'date':strftime("%a, %d %b %Y %H:%M:%S +0000", gmtime()), 'success': True, 'report': '123'})
    #last = report_sqllite.last()
    #one = report_sqllite.get_by_id(last[0])
    #all = report_sqllite.all()

    #report_mongo.add({'date':strftime("%a, %d %b %Y %H:%M:%S +0000", gmtime()), 'success': True, 'report': '123'})
    #last1 = report_mongo.last()
    #one1 = report_mongo.get_by_id(last1['_id'])
    #all1 = report_mongo.all()

    
    settings_sqllite.add('breakfast', json.dumps({'start':9, 'end': 10}))
    breakfast = settings_sqllite.get('breakfast')
    #settings_sqllite.update('breakfast','value2')
    #breakfast = settings_sqllite.get('breakfast')
    print breakfast

    settings_mongo.add('breakfast', json.dumps({'start':9, 'end': 10}))
    breakfast = json.loads(settings_mongo.get('breakfast'))
    #settings_mongo.update('breakfast','value2')
    #breakfast = settings_mongo.get('breakfast')
    print breakfast

    #date = datetime.strptime(last[1], "%a, %d %b %Y %H:%M:%S +0000")
    #day = date.day
    #month = date.month
    #hour = date.hour
    #minute = date.minute

    # We can also close the connection if we are done with it.
    # Just be sure any changes have been committed or they will be lost.

# Run the job
#job.enter(JOB_DIFF, 1, execute, (job,))
#job.run()
main()
