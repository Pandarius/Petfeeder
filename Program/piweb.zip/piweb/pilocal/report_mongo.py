import ConfigParser
from pymongo import MongoClient
from bson.objectid import ObjectId

class ReportMongo(object):
    """Report MongoDB provider"""
    def __init__(self):
        config = ConfigParser.RawConfigParser()
        config.read('pilocal.cfg')
        self._reports = MongoClient(config.get('mongo', 'connection'))[config.get('mongo', 'db')]['reports']

    def get_by_id(self, id):
        if type(id) is ObjectId:
            return self._reports.find_one({'_id': id})
        return self._reports.find_one({'_id': ObjectId(id)})

    def all(self):
        return self._reports.find().limit(500).sort('date', -1)

    def last(self):
        return self._reports.find().limit(1).sort('date', -1)[0]

    def add(self, doc):
        doc['_id'] = self._reports.insert_one(doc).inserted_id
        return doc
