﻿var app = angular
    .module("app", ["firebase"])
    .controller("home", function ($scope, $firebaseArray) {

        var fireRef = new Firebase('https://pi-proj.firebaseio.com/msg');
        var query = fireRef.limitToLast(30);
        $scope.msgs = $firebaseArray(query);

    });