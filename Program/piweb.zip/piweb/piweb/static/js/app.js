﻿// Initialize Firebase
var config = {
    apiKey: "AIzaSyBYgp-Pq7Fhj3-ISotv31Abc0uzCrx7ClI",
    authDomain: "pi-proj.firebaseapp.com",
    databaseURL: "https://pi-proj.firebaseio.com",
    storageBucket: "pi-proj.appspot.com",
};
firebase.initializeApp(config);

var app = angular
    .module("app", ["firebase"])
    .controller("home", function ($scope, $firebaseArray) {

        // Get the details
        var details = firebase.database().ref().child("details");
        $scope.details = $firebaseArray(details);

        //$scope.details.$add({
        //    pressure: 0,
        //    temprature: 0,
        //    moisture: 0,
        //    danger_client: true,
        //    danger_server: true
        //});
        

        // Get the history
        var history = firebase.database().ref().child("piproj_history");
        var query = history.limitToLast(10);
        $scope.history = $firebaseArray(query);
        
        // Update the status
        $scope.update = function () {
            var status = $scope.details[0].danger_client;
            status = !status;

            $scope.history.$add({
                date:  new Date().toJSON(),
                danger: status
            });

            $scope.details[0].danger_server = status;
            $scope.details.$save($scope.details[0]);
        }
    });


//{
//    "rules": {
//        ".read": true,
//        ".write": "auth.uid === 'piweb'"
//    }
//}