from setuptools import setup

setup(name='piweb',
      version='1.0',
      description='OpenShift App',
      author='Velin Georgiev, Dimitar ...',
      author_email='piweb@example.com',
      url='http://www.python.org/sigs/distutils-sig/',
      install_requires=['Flask'],
     )
