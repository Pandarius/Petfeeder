For information about markers, consult the documentation:

https://docs.openshift.org/origin-m4/oo_user_guide.html#using-cartridges
https://docs.openshift.org/origin-m4/oo_cartridge_guide.html#markers-7

