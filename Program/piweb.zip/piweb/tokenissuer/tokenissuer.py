from firebase_token_generator import create_token
from datetime import datetime, timedelta
import ConfigParser, requests, json

# Configuration variables.
config = ConfigParser.RawConfigParser()
config.read('tokenissuer.cfg')
secret = config.get('firebase', 'secret')

# Security token to authenticate against the database.
payload = {"uid": "picat" }
options = {"expires": datetime.now() + timedelta(days=3600)}
token = create_token(secret, payload, options)
print token